/**
 * Placeholder crawler script (Notion-backed mode)
 * You can later swap to Supabase-backed crawler for hash monitoring.
 *
 * For now: prints a reminder.
 */
console.log("Crawler not enabled in Notion-backed mode. Use Notion 'Needs Review' + manual verification, or add Supabase later.");
